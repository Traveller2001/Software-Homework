import os.path
import time
from selenium import webdriver
from lxml import etree
from selenium.webdriver import ChromeOptions
from time import sleep
from selenium.webdriver.chrome.service import Service
option=ChromeOptions()
option.add_experimental_option('excludeSwitches',['enable-automation'])
s = Service(executable_path=r'C:\Program Files\python38\chromedriver.exe')
driver = webdriver.Chrome(service=s,options=option)
if not os.path.exists('./yiqing'):
    os.mkdir('./yiqing')

for page in range( 1, 42 ):
    if page==1:
        new_url='http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
    else:
        new_url='http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_'+str(page)+'.shtml'
    driver.get(new_url)
    sleep(3)
    page_text=driver.page_source
    tree=etree.HTML(page_text)
    li_list=tree.xpath('/html/body/div[3]/div[2]/ul/li')
    for li in li_list:
        time=li.xpath('./span/text()')
        link="http://www.nhc.gov.cn"+li.xpath('./a/@href')[0]
        driver.get(link)
        sleep(3)
        page_text1 = driver.page_source
        tree1=etree.HTML(page_text1)
        titles = tree1.xpath('//div[@class="tit"]/text()')
        paras = tree1.xpath('//div[@class="con"]//text()')
        paras=str(paras)
        for tit in titles:
            title1='yiqing/'+str(time)+tit+".txt"
            with open(title1,'w',encoding='utf-8') as fp:
                fp.write(paras)
                print("爬取成功！！！")



